package es.arsys;

import java.util.Scanner;

public class Bucle_While_Do_While {

    public static void main(String[] args) {
        // Juego de adivinar el numero

        // Generar un numero aleatorio del 1 al 10
        int aleatorio = (int) (Math.random() * 10) + 1;
        int numero = 0;
        Scanner sc = new Scanner(System.in);

        // preguntar al usuario hasta que acierte
        // Damos pistas: te has pasado, te has quedado corto
        do{
            System.out.println("Adivina numero del 1 al 10: ");
            numero = sc.nextInt();

            if (aleatorio > numero)
                System.out.println("Te has quedado corto, prueba de nuevo");
            else if (aleatorio < numero)
                System.out.println("Te has pasado, prueba de nuevo");

        } while (aleatorio != numero);
        System.out.println("Acertaste !!!!");
    }
}
