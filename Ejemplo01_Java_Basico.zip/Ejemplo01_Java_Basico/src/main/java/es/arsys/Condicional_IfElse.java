package es.arsys;

import java.util.Scanner;

public class Condicional_IfElse {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce letra del dia de la semana");
        String dia = sc.nextLine();

        // if elseif else mostrar el dia de la semana al que pertenece
        if (dia.equals("l") || dia.equals("L")){
            System.out.println("Es lunes");
        } else if (dia.equals("m") || dia.equals("M")){
            System.out.println("Es martes");
        } else if (dia.equals("x") || dia.equals("X")){
            System.out.println("Es miercoles");
        } else if (dia.equals("j") || dia.equals("J")){
            System.out.println("Es jueves");
        } else if (dia.equals("v") || dia.equals("V")){
            System.out.println("Es viernes");
        } else if (dia.equals("s") || dia.equals("S")){
            System.out.println("Es sabado");
        } else if (dia.equals("d") || dia.equals("D")){
            System.out.println("Es domingo");
        } else {
            System.out.println("Dia no valido");
        }
    }
}
