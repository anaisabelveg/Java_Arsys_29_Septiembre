package es.arsys;

public class ManejoStrings {

    public static void main(String[] args) {

        String cadena = "Bienvenidos al curso de Java";

        // Longitud
        System.out.println("Longitud: " + cadena.length());

        // Mayusculas
        System.out.println("Mayusculas: " + cadena.toUpperCase());

        // Minusculas
        System.out.println("Minusculas: " + cadena.toLowerCase());

        // Primera a:
        System.out.println("Primera a: " + cadena.indexOf("a"));

        // Ultima a:
        System.out.println("Ultima a: " + cadena.lastIndexOf("a"));

        // Extraer la palabra Bienvenidos
        System.out.println(cadena.substring(0, cadena.indexOf(" ")));

        // Extraer la palabra Java
        System.out.println(cadena.substring(cadena.lastIndexOf(" ") + 1) );

        // Reemplazar la letra a por A
        System.out.println(cadena.replace('a', 'A'));
    }
}