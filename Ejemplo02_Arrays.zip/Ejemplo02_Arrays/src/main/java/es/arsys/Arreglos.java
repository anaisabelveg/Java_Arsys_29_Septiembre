package es.arsys;

import java.util.Arrays;

public class Arreglos {
    public static void main(String[] args) {
        // Los arrays son estructuras fijas
        // no son redimensionables
        // todos los elementos son del mismo tipo

        // Declarar una variable de tipo array
        int numeros[], a;   // a es una variable de tipo entero
        int [] numeros2, b;  // b es una variable de tipo array
        int[] numeros3, c;   // c es una variable de tipo array

        // Crear el array vacio
        numeros = new int[4];   // obligatorio poner la longitud del array

        // Crear el array con valores iniciales
        numeros2 = new int[]{1,2,3,4,5,6};
        // numeros3 = {1,2,3,4,5,6};    Error de compilacion
        int numeros4[] = {1,2,3,4,5,6};

        // acceder a los elementos
        // array[indice]   el indice siempre empieza en 0
        numeros[0] = 1;
        numeros[1] = 10;
        numeros[2] = 100;
        numeros[3] = 1000;

        // Recorrer un array con for tradicional
        for(int idx=0; idx < numeros.length; idx++){
            System.out.println(numeros[idx]);
        }

        // Recorrer un array con for-each (Novedad en Java 5)
        for (int num : numeros) {
            System.out.println(num);
        }

        // Como no son redimensionables, creo un array grande y copio los datos
        int grande[] = new int[10];
        System.arraycopy(numeros, 0, grande, 0, numeros.length);

        // Mostrar el array
        System.out.println(grande);
        System.out.println(Arrays.toString(grande));

    }
}