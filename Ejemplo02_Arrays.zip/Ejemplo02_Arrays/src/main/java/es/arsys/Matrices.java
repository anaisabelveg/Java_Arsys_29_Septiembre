package es.arsys;

import java.util.Arrays;

public class Matrices {
    public static void main(String[] args) {
        // Declarar una variable de tipo array de 2 dimensiones
        int numeros[][];
        int [][] numeros2;

        // Crear el array vacio
        numeros = new int[2][3];   // obligatorio poner la longitud del array [fila][columna]

        // Llenado de datos
        numeros[0][0] = 7;
        numeros[0][1] = 1;
        numeros[0][2] = 4;
        numeros[1][0] = 6;
        numeros[1][1] = 3;
        numeros[1][2] = 9;

        // Crear el array con valores iniciales
        numeros2 = new int[][]{ {7,1,4}, {6,3,9} };
        //numeros2 = { {7,1,4}, {6,3,9} };   Error de compilacion
        int numeros3[][] = { {7,1,4}, {6,3,9} };

        // Recorrer una matriz con for tradicional
        for(int fila=0; fila < numeros.length; fila++){
            for(int col=0; col < numeros[fila].length; col++){
                System.out.print(numeros[fila][col] + "\t");
            }
            System.out.println();
        }

        // Recorrer un array con for-each (Novedad en Java 5)
        for (int fila[] : numeros) {
            for(int num : fila)
                System.out.print(num + "\t");
            System.out.println();
        }

        // Como no son redimensionables, creo un array grande y copio los datos
        int grande[][] = new int[10][10];
        System.arraycopy(numeros, 0, grande, 0, numeros.length);

        // Mostrar el array
        System.out.println(grande);
        System.out.println(Arrays.toString(grande));
        System.out.println(Arrays.deepToString(grande));
    }
}