package es.arsys;

import es.arsys.models.Cliente;
import es.arsys.models.Direccion;

public class Main {
    public static void main(String[] args) {

        // Crear un objeto o instancia de la clase Cliente
        Cliente cliente1 = new Cliente();   // new Constructor()

        // Asignar valores al objeto creado
        // objeto.recurso
        cliente1.nombre = "Fruteria Perez";
        cliente1.cif = "B-12345678";
        cliente1.vip = false;
        cliente1.direccion = new Direccion("Mayor", 5, "Madrid");

        System.out.println(cliente1);
        System.out.println(cliente1.mostrarInfo());

        // Cambiar el cliente a vip
        cliente1.cambiarVip(true);
        System.out.println(cliente1.mostrarInfo());

        // Crear un segundo cliente y pasamos todos los datos al constructor
        Cliente cliente2 = new Cliente("Carniceria Santos", "B-98765432", false,
                new Direccion("Diagonal", 83, "Barcelona"));
        System.out.println(cliente2.mostrarInfo());

    }
}