package es.arsys.models;

public class Cliente {

    // propiedades, campos, atributos, carácteristicas del Cliente
    public String nombre;
    public String cif;
    public boolean vip;
    public Direccion direccion;

    // El compilador, si la clase no tiene ningun constructor
    // agrega el constructor por defecto (sin argumentos)
    // Mantener el constructor por defecto
    public Cliente() {
    }

    // Crear el constructor completo (recibe todos los valores de las propiedades)
    public Cliente(String nombre, String cif, boolean vip, Direccion direccion) {
        this.nombre = nombre;
        this.cif = cif;
        this.vip = vip;
        this.direccion = direccion;
    }

    // metodos, funciones, acciones
    public String mostrarInfo(){
        return  "Nombre: " + nombre + ", CIF: " + cif + ", es vip? " + vip +
                ", Direccion: " + direccion.mostrarInfo();
    }

    // Cuando el metodo no retorna nada es de tipo void
    public void cambiarVip(boolean nuevoValor){
        vip = nuevoValor;
    }

}
