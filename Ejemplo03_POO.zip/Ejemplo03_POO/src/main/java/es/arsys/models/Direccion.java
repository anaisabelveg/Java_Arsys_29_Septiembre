package es.arsys.models;

public class Direccion {

    public String calle;
    public int numero;
    public String poblacion;

    public Direccion() {
    }

    public Direccion(String calle, int numero, String poblacion) {
        this.calle = calle;
        this.numero = numero;
        this.poblacion = poblacion;
    }

    public String mostrarInfo(){
        // Mayor, 5 - Madrid
        return calle + ", " + numero + " - " + poblacion;
    }
}
