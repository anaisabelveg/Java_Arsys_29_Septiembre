package es.arsys;

import es.arsys.models.Alumno;
import es.arsys.utils.ComparadorNota;

import java.util.*;

public class ClasificarColecciones {

    public static void main(String[] args) {
        // Crear arbol de alumnos ordenados por nota
        //Set<Alumno> alumnos = new TreeSet<>(new ComparadorNota());

        // Crear arbol de alumnos ordenados por nombre
        Set<Alumno> alumnos = new TreeSet<>( (alum1,alum2) -> alum1.getNombre().compareTo(alum2.getNombre()) );

        // Agregar 5 alumnos
        alumnos.add(new Alumno(1, "Juan", "Perez", 'H', 7.5, false));
        alumnos.add(new Alumno(2, "Maria", "Sanchez", 'M', 4.2, true));
        alumnos.add(new Alumno(3, "Pedro", "Gonzalez", 'H', 9.2, false));
        alumnos.add(new Alumno(4, "Luis", "Rodriguez", 'H', 8.3, false));
        alumnos.add(new Alumno(5, "Sara", "Garcia", 'M', 10, true));

//        for (Alumno alumno: alumnos) {
//            System.out.println(alumno);
//        }
        alumnos.forEach(System.out::println);
        System.out.println("--------------------------");

        // Crear una lista a partir del arbol de alumnos
        List<Alumno> lista = new ArrayList<>(alumnos);

        // utilizando lambdas ordenar por numero de alumno ascendente
        lista.sort((a1, a2) -> a1.getNumAlumno() - a2.getNumAlumno());
        lista.forEach(System.out::println);
        System.out.println("--------------------------");

        // utilizando lambdas ordenar por numero de alumno descendente
        lista.sort((a1, a2) -> a2.getNumAlumno() - a1.getNumAlumno());
        lista.forEach(System.out::println);
        System.out.println("--------------------------");

        // utilizando lambdas ordenar por apellido de alumno descendente
        lista.sort((alum1,alum2) -> alum2.getApellido().compareTo(alum1.getApellido()));
        lista.forEach(System.out::println);
        System.out.println("--------------------------");

        // utilizando lambdas ordenar por nota ascendente
        lista.sort(Comparator.comparingDouble(Alumno::getNota));
        lista.forEach(System.out::println);
        System.out.println("--------------------------");

        // utilizando lambdas ordenar por nota descendente
        lista.sort(Comparator.comparingDouble(Alumno::getNota).reversed());
        lista.forEach(System.out::println);
        System.out.println("--------------------------");
    }
}
