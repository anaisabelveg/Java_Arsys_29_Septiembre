package es.arsys;

import es.arsys.business.ItfzFuncional;

public class Main {
    public static void main(String[] args) {

        // lambda     (parametros) -> cuerpo de la funcion

        // los nombres de los parametros no se tienen que llamar igual
        // los parentesis son obligatorios cuando no hay parametros o hay mas de uno
        // Si solo tengo un parametro puedo eliminar los parentesis
        ItfzFuncional lambda1 = (nom, edad2) -> "nombre: " + nom + ", edad: " + edad2;
        System.out.println(lambda1.infoPersonas("Pepito", 36));

        // las llaves si hay mas de una linea en el cuerpo de la funcion son obligatorios
        // si ponemos llaves el return es obligatorio
        ItfzFuncional lambda2 = (nombre, edad) -> {
            return "nombre: " + nombre + ", edad: " + edad;
        };
        System.out.println(lambda2.infoPersonas("Juan", 21));

        ItfzFuncional lambda3 = (nombre, edad) -> {
            edad++;
            nombre = nombre.toUpperCase();
            return "nombre: " + nombre + ", edad: " + edad;
        };
        System.out.println(lambda3.infoPersonas("Maria", 28));

    }
}