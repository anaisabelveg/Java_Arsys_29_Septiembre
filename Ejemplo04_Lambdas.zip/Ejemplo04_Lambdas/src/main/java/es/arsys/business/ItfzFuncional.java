package es.arsys.business;

// Es una interface funcional porque tiene un solo metodo abstracto
@FunctionalInterface
public interface ItfzFuncional {

    String infoPersonas(String nombre, int edad);
}
