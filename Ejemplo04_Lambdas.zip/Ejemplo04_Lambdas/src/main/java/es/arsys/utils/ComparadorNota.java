package es.arsys.utils;

import es.arsys.models.Alumno;

import java.util.Comparator;

public class ComparadorNota implements Comparator<Alumno> {

    @Override
    public int compare(Alumno alum1, Alumno alum2) {
        // retorna 1 o cualquier numero > 0 alum1 es mayor que alum2
        // retorna -1 o cualquier numero < 0 alum1 es menor que alum2
        // retorna 0 alum1 es igual que alum2
        if (alum1.getNota() > alum2.getNota()){
            return 1;
        } else if (alum1.getNota() < alum2.getNota()){
            return -1;
        } else {
            return 0;
        }
    }
}
