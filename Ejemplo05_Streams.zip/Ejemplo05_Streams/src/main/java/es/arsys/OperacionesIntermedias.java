package es.arsys;

import es.arsys.models.Provincia;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class OperacionesIntermedias {
    public static void main(String[] args) {

        List<Provincia> lista = Arrays.asList(
                new Provincia("Madrid", 87, 67_886_543, 28, "Español", "Madrid", 90.67),
                new Provincia("Valencia", 45, 7876876, 46 , "Valenciano", "Valencia", 91.3),
                new Provincia("Coruña", 39, 54545, 9, "Gallego", "Coruña", 78.23),
                new Provincia("Toledo", 26, 3677556, 38, "Español", "Toledo", 35.17),
                new Provincia("Ourense", 29, 788866, 27, "Gallego", "Ourense", 28.68),
                new Provincia("Cuenca", 15, 986442, 16, "Español", "Cuenca", 34.12),
                new Provincia("Barcelona", 74, 556779, 8, "Catalan", "Barcelona", 97.25),
                new Provincia("Zamora", 28, 987656, 42, "Español", "Zamora", 56.34),
                new Provincia("Guipuzcoa", 35, 432223, 20, "Euskera", "San Sebastian", 48.23),
                new Provincia("Vizcaya", 48, 567654, 6, "Euskera", "Bilbao", 54.89)
        );

        // Mostrar el nombre de las provincias que tienen una densidad de poblacion superior a 50
        lista.stream()
                .filter(prov -> prov.getDensidadPoblacion() > 50)
                .map(provincia -> provincia.getNombre())
                .forEach(System.out::println);
        System.out.println("-----------------------------");

        // Mostrar los distintos dialectos ordenados
        lista.stream()
                .map(provincia -> provincia.getDialecto())
                .distinct()
                .sorted()
                .forEach(System.out::println);
        System.out.println("-----------------------------");

        // Mostrar las 3 primeras provincias
        lista.stream()
                .limit(3)
                .forEach(System.out::println);
        System.out.println("-----------------------------");

        // Si no queremos modificar la lista original
        // Crear nueva lista
        List<Provincia> copia = new ArrayList<>();
        lista.forEach(provincia -> copia.add(new Provincia(provincia)));

        // Mostrar las provincias que tienen menos de 40 localidades ordenadas por codigo postal
        // Queremos que el nombre aparezca en mayusculas
        copia.stream()
                .filter(prov -> prov.getNumLocalidades() < 40)
                .sorted(Comparator.comparingInt(Provincia::getCodigoPostal))
                //.map(prov -> prov.getNombre().toUpperCase())// muestra solo el nombre
                .map(prov -> {
                    prov.setNombre(prov.getNombre().toUpperCase());
                    return prov;  // muestra la provincia
                })
                .forEach(System.out::println);
        System.out.println("-----------------------------");

        // Mostrar las provincias con dialecto Español ordenadas por numero de localidades
        // Que aparezca la cadena: Nombre - Dialecto - Codigo postal
        lista.stream()
                .filter(prov -> "Español".equals(prov.getDialecto()))
                .sorted(Comparator.comparingInt(Provincia::getNumLocalidades))
                .map(prov -> prov.getNombre() + " - " + prov.getDialecto() + " - " + prov.getCodigoPostal())
                .forEach(System.out::println);
        System.out.println("-----------------------------");

        // peek -> realiza una operacion y devuelve el elemento al stream
        // Util para ir mostrando resultados intermedios
        lista.stream()
                .peek(prov -> System.out.println("Procesando " + prov + "-------------------"))
                .filter(prov -> prov.getDensidadPoblacion() > 50)
                .peek(prov -> System.out.println("Resultado " + prov + "-------------------"))
                .map(provincia -> provincia.getNombre())
                .forEach(System.out::println);
        System.out.println("-----------------------------");

    }
}