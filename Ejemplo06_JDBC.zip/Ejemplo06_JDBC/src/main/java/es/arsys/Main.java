package es.arsys;

import es.arsys.models.Producto;
import es.arsys.persistence.ProductosDAO;

import java.util.Optional;

public class Main {
    public static void main(String[] args) {

        ProductosDAO dao = new ProductosDAO();
        for(int i=1; i<=5; i++){
            //dao.insertarProducto(new Producto(i, "Producto " + i, i*100));
        }

        //dao.consultarTodos().forEach(System.out::println);

        Optional<Producto> opProducto = dao.buscarProducto(3754);
        if (opProducto.isPresent()){
            System.out.println(opProducto.get());
        } else {
            System.out.println("Producto no encontrado");
        }


    }
}