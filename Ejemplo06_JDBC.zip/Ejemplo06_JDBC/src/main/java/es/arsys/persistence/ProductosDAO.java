package es.arsys.persistence;

import es.arsys.models.Producto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductosDAO {

    private Connection con;

    public Optional<Producto> buscarProducto(int id){
        try {
            abrirConexion();

            String sql = "select * from PRODUCTOS where ID=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            // Aunque solo exista un registro hay que avanzar el cursor
            if(rs.next()){
                return Optional.of(new Producto(rs.getInt("ID"),
                                rs.getString("DESCRIPCION"),
                                rs.getDouble("PRECIO") ));
            }

        } catch (Exception ex){
            System.out.println("Error al consultar los productos");
            ex.printStackTrace();
        } finally {
            cerrarConexion();
        }
        // Si no encuentra el producto
        return Optional.empty();
    }

    public List<Producto> consultarTodos(){
        List<Producto> lista = new ArrayList<>();
        try {
            abrirConexion();

            String sql = "select * from PRODUCTOS";
            // Opcion 1: recomendado porque las queries con prepared statement son precompiladas y mas rapidas
            //PreparedStatement pst = con.prepareStatement(sql);

            // Opcion 2:
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while(rs.next()){
                lista.add(new Producto(rs.getInt("ID"),
                        rs.getString("DESCRIPCION"),
                        rs.getDouble("PRECIO")
                ));
            }

        } catch (Exception ex){
            System.out.println("Error al consultar los productos");
            ex.printStackTrace();
        } finally {
            cerrarConexion();
        }
        return lista;
    }

    public void insertarProducto(Producto producto){
        try {
            abrirConexion();

            String sql = "insert into PRODUCTOS values (?,?,?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, producto.getID());
            pst.setString(2, producto.getDescripcion());
            pst.setDouble(3, producto.getPrecio());
            int registros = pst.executeUpdate();
        } catch (Exception ex){
            System.out.println("Error al insertar el producto " + producto);
            ex.printStackTrace();
        } finally {
            cerrarConexion();
        }
    }

    private void abrirConexion(){
        try {
            // Cargar el driver de la base de datos
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Arsys", "root", "");
        } catch (ClassNotFoundException ex){
            System.out.println("Driver no encontrado");
            ex.printStackTrace();
        } catch (SQLException ex){
            System.out.println("Error al abrir conexion");
            ex.printStackTrace();
        }
    }

    private void cerrarConexion(){
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexion");
            e.printStackTrace();
        }
    }

}
