package es.arsys;

import es.arsys.entities.Persona;
import es.arsys.models.Direccion;
import es.arsys.models.EstadoCivil;
import es.arsys.persistence.PersonasDAO;

import java.util.Date;

public class Main {
    public static void main(String[] args) {

        PersonasDAO dao = new PersonasDAO();

        dao.insertarPersona(new Persona("11111111-A", "Maria", "Perez",
                new Direccion("Mayor", 5, "Madrid"), EstadoCivil.SOLTERO, new Date("20/4/1972"),
                "Enfermera. Universidad Complutense de Madrid. Master en Rey Juan Calos"));

        dao.insertarPersona(new Persona("22222222-B", "Pedro", "Arias",
                new Direccion("Diagonal", 87, "Barcelona"), EstadoCivil.CASADO, new Date("26/2/1975"),
                "Arquitecto. Universidad UOC de Barcelona."));
        
    }
}