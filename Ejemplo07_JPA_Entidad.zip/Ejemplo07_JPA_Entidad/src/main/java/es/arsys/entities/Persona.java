package es.arsys.entities;

import es.arsys.models.Direccion;
import es.arsys.models.EstadoCivil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "Ejemplo7_Personas")
@SecondaryTable(name = "Ejemplo7_CV",
        pkJoinColumns = {@PrimaryKeyJoinColumn(name = "NIF", referencedColumnName = "NIF")}
)
//@SecondaryTables({@SecondaryTable(), @SecondaryTable()})
public class Persona implements Serializable {

    @Id
    @Column(name = "NIF", nullable = false, unique = true, length = 20)
    private String nif;

    @Column(name = "NOMBRE", length = 50)
    private String nombre;

    @Column(name = "APELLIDO", length = 50)
    private String apellido;

    @Embedded
    private Direccion direccion;

    @Enumerated(EnumType.STRING)
    @Column(name = "ESTADO_CIVIL")
    private EstadoCivil estado;

    @Temporal(TemporalType.DATE)
    @Column(name = "FECHA_NACIMIENTO")
    private Date fechaNacimiento;

    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "CURRICULUM_VITAE", table = "Ejemplo7_CV")
    private String cv;

    public Persona() {
    }

    public Persona(String nif, String nombre, String apellido, Direccion direccion, EstadoCivil estado, Date fechaNacimiento, String cv) {
        this.nif = nif;
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.estado = estado;
        this.fechaNacimiento = fechaNacimiento;
        this.cv = cv;
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public EstadoCivil getEstado() {
        return estado;
    }

    public void setEstado(EstadoCivil estado) {
        this.estado = estado;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getCv() {
        return cv;
    }

    public void setCv(String cv) {
        this.cv = cv;
    }

    @Override
    public String toString() {
        return "Persona{" +
                "nif='" + nif + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", direccion=" + direccion +
                ", estado=" + estado +
                ", fechaNacimiento=" + fechaNacimiento +
                ", cv='" + cv + '\'' +
                '}';
    }
}
