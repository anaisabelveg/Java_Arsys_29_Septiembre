package es.arsys.persistence;

import es.arsys.entities.Persona;

import javax.persistence.*;
import java.util.List;

public class PersonasDAO {

    private EntityManagerFactory emf;

    public PersonasDAO() {
        emf = Persistence.createEntityManagerFactory("PU");
    }

    public void cerrar(){
        emf.close();
    }

    public void insertarPersona(Persona persona){
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(persona);
            et.commit();
        } catch (Exception ex){
            et.rollback();
            ex.printStackTrace();
        } finally {
            em.close();
        }
    }

    public Persona buscarPersona(String nif){
        EntityManager em = emf.createEntityManager();
        Persona persona = em.find(Persona.class, nif);
        em.close();   // cerrar la conexion
        return persona;
    }

    public List<Persona> consultarTodos(){
        // La conexion se abre en el momento que creamos el EntityManager
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("select p from Persona p");
        List<Persona> lista = query.getResultList();
        em.close();   // cerrar la conexion
        return  lista;
    }
}
