package es.arsys.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "Ejemplo8_Nifs")
public class Nif implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id_nif")   // PK  id_xxx      FK  xxx_id
    private Long id;

    private char letra;

    private long numero;

    // Nif es la entidad menos importante de las 2 (subordinada)
    // mappedBy va en la subordinada
    @OneToOne(mappedBy = "nif")   // es la propiedad nif en la entidad Persona
    private Persona persona;

    public Nif() {
    }

    public Nif(char letra, long numero) {
        this.letra = letra;
        this.numero = numero;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public char getLetra() {
        return letra;
    }

    public void setLetra(char letra) {
        this.letra = letra;
    }

    public long getNumero() {
        return numero;
    }

    public void setNumero(long numero) {
        this.numero = numero;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Nif nif = (Nif) o;
        return letra == nif.letra && numero == nif.numero;
    }

    @Override
    public int hashCode() {
        return Objects.hash(letra, numero);
    }

    @Override
    public String toString() {
        return "Nif{" +
                "id=" + id +
                ", letra=" + letra +
                ", numero=" + numero +
                '}';
    }
}
