package es.arsys.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "Ejemplo8_Personas")
public class Persona implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id_persona")   // PK  id_xxx      FK  xxx_id
    private Long id;

    private String nombre;

    // En OneToOne tu eliges donde creas las FK y las operaciones en cascada
    // Lo hago en Persona porque entendemos que es la entidad mas importante (propietaria)
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "nif_id", referencedColumnName = "id_nif")
    private Nif nif;

    // Quien tiene el oneToMany es la entidad subordinada
    @OneToMany(mappedBy = "persona", cascade = CascadeType.ALL)
    private Set<Telefono> telefonos = new HashSet<>();

    // En ManyToMany tu eliges donde creas la tabla intermedia y las operaciones en cascada
    // Aqui no se puede relacionar con FK sino con tabla intermedia
    @ManyToMany(cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
    @JoinTable(name = "Ejemplo8_Personas_Coches",
            joinColumns =  @JoinColumn(name = "persona_id", referencedColumnName = "id_persona") ,
            inverseJoinColumns = @JoinColumn(name = "coche_id", referencedColumnName = "id_coche")
    )
    private Set<Coche> coches = new HashSet<>();

    public Persona() {
    }

    public Persona(String nombre, Nif nif) {
        this.nombre = nombre;
        this.nif = nif;
    }

    // Metodos de sincronizacion
    // uno por cada propiedad de tipo coleccion
    public void addTelefono(Telefono t){
        telefonos.add(t);
        t.setPersona(this);
    }

    public void addCoche(Coche c){
        coches.add(c);
        c.getPropietarios().add(this);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Nif getNif() {
        return nif;
    }

    public void setNif(Nif nif) {
        this.nif = nif;
    }

    public Set<Telefono> getTelefonos() {
        return telefonos;
    }

    public void setTelefonos(Set<Telefono> telefonos) {
        this.telefonos = telefonos;
    }

    public Set<Coche> getCoches() {
        return coches;
    }

    public void setCoches(Set<Coche> coches) {
        this.coches = coches;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Persona persona = (Persona) o;
        return Objects.equals(id, persona.id) && Objects.equals(nombre, persona.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre);
    }

    @Override
    public String toString() {
        return "Persona{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", nif=" + nif +
                ", telefonos=" + telefonos +
                ", coches=" + coches +
                '}';
    }
}
