package es.arsys.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "Ejemplo8_Telefonos")
public class Telefono implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id_telefono")   // PK  id_xxx      FK  xxx_id
    private Long id;

    private long numero;

    // Quien tiene el ManyToOne es la entidad propietaria
    @ManyToOne
    @JoinColumn(name = "persona_id", referencedColumnName = "id_persona")
    private Persona persona;

    public Telefono() {
    }

    public Telefono(long numero) {
        this.numero = numero;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public long getNumero() {
        return numero;
    }

    public void setNumero(long numero) {
        this.numero = numero;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Telefono telefono = (Telefono) o;
        return numero == telefono.numero;
    }

    @Override
    public int hashCode() {
        return Objects.hash(numero);
    }

    @Override
    public String toString() {
        return "Telefono{" +
                "id=" + id +
                ", numero=" + numero +
                '}';
    }
}
