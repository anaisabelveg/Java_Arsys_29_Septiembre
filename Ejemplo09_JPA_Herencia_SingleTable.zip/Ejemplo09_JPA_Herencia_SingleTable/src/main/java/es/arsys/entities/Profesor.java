package es.arsys.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import java.io.Serializable;

@Entity
@DiscriminatorValue(value = "profe")
public class Profesor extends Persona implements Serializable {

    private String titulacion;

    public Profesor() {
    }

    public Profesor(String nombre, String apellido, String titulacion) {
        super(nombre, apellido);
        this.titulacion = titulacion;
    }

    public String getTitulacion() {
        return titulacion;
    }

    public void setTitulacion(String titulacion) {
        this.titulacion = titulacion;
    }

    @Override
    public String toString() {
        return "Profesor{" +
                super.toString() +
                "titulacion='" + titulacion + '\'' +
                "} ";
    }
}
