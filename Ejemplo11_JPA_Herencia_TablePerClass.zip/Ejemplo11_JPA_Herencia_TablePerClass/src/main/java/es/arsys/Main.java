package es.arsys;

import es.arsys.entities.Alumno;
import es.arsys.entities.Persona;
import es.arsys.entities.Profesor;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {
    public static void main(String[] args) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        Persona persona = new Persona("Juan", "Lopez");
        Alumno alumno = new Alumno("Maria", "Perez", "Spring");
        Profesor profesor = new Profesor("Jose", "Sanchez", "Ingeniero Informatico");

        try {
            et.begin();
            em.persist(persona);
            em.persist(alumno);
            em.persist(profesor);
            et.commit();
            System.out.println("Entidades creadas");
        } catch (Exception ex){
            et.rollback();
            ex.printStackTrace();
        } finally {
            em.close();
        }
    }
}