package es.arsys.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "Ejemplo11_Alumnos")
public class Alumno extends Persona implements Serializable {

    private String curso;

    public Alumno(String nombre, String apellido, String curso) {
        super(nombre, apellido);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                super.toString() +
                "curso='" + curso + '\'' +
                "} ";
    }
}
