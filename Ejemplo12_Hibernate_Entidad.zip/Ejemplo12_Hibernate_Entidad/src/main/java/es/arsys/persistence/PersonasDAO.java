package es.arsys.persistence;

import es.arsys.entities.Persona;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import java.util.List;

public class PersonasDAO {

    public void insertarPersona(Persona persona){
        StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate2.cfg.xml").build();
        SessionFactory sf = new MetadataSources(registry).buildMetadata().buildSessionFactory();
        Session session = sf.openSession();  // En este momento se abre la conexion a la BDD
        Transaction tx = session.getTransaction();

        try {
            tx.begin();
            //session.persist(persona);
            session.save(persona);
            tx.commit();
        } catch (Exception ex){
            tx.rollback();
            ex.printStackTrace();
        } finally {
            session.close();   // cerrar la conexion a la BBDD
            sf.close();
        }
    }

    public Persona buscarPersona(String nif){
        StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate2.cfg.xml").build();
        SessionFactory sf = new MetadataSources(registry).buildMetadata().buildSessionFactory();
        Session session = sf.openSession();
        Persona persona = session.get(Persona.class, nif);
        session.close();   // cerrar la conexion
        sf.close();
        return persona;
    }

    public List<Persona> consultarTodos(){
        StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate2.cfg.xml").build();
        SessionFactory sf = new MetadataSources(registry).buildMetadata().buildSessionFactory();
        Session session = sf.openSession();
        Query<Persona> query = session.createQuery("from Persona p");
        List<Persona> lista = query.getResultList();
        session.close();  // cerrar la conexion
        sf.close();
        return  lista;
    }
}
