package es.arsys;

import es.arsys.entities.Coche;
import es.arsys.entities.Nif;
import es.arsys.entities.Persona;
import es.arsys.entities.Telefono;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main {
    public static void main(String[] args) {

        StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        SessionFactory sf = new MetadataSources(registry).buildMetadata().buildSessionFactory();
        Session session = sf.openSession();  // En este momento se abre la conexion a la BDD
        Transaction tx = session.getTransaction();

        // Crear los nifs
        Nif n1 = new Nif('A', 1111111L);
        Nif n2 = new Nif('B', 2222222L);
        Nif n3 = new Nif('c', 3333333L);

        // Crear los telefonos
        Telefono t1 = new Telefono(616111111L);
        Telefono t2 = new Telefono(616222222L);
        Telefono t3 = new Telefono(616333333L);
        Telefono t4 = new Telefono(616444444L);
        Telefono t5 = new Telefono(616555555L);
        Telefono t6 = new Telefono(616666666L);

        // Crear coches
        Coche c1 = new Coche("1111-MDB", "A3");
        Coche c2 = new Coche("2222-MDB", "A4");
        Coche c3 = new Coche("3333-MDB", "A5");
        Coche c4 = new Coche("4444-MDB", "A6");

        // Crear las personas
        Persona p1 = new Persona("Juan", n1);
        Persona p2 = new Persona("Maria", n2);
        Persona p3 = new Persona("Pedro", n3);

        // Asignar telefonos a cada persona
        p1.addTelefono(t1);
        p1.addTelefono(t2);
        p2.addTelefono(t3);
        p2.addTelefono(t4);
        p3.addTelefono(t5);
        p3.addTelefono(t6);

        // Asignar coches a cada persona
        p1.addCoche(c1);
        p1.addCoche(c2);
        p1.addCoche(c3);

        p2.addCoche(c2);
        p2.addCoche(c3);
        p2.addCoche(c4);

        p3.addCoche(c1);
        p3.addCoche(c4);

        try {
            tx.begin();
            session.persist(p1);
            session.persist(p2);
            session.persist(p3);
            tx.commit();
            System.out.println("Entidades creadas");
        } catch (Exception ex){
            tx.rollback();
            ex.printStackTrace();
        } finally {
            session.close();
        }
    }
}