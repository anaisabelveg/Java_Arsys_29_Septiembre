package es.arsys.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class Persona implements Serializable {

    private Long id;
    private String nombre;
    private Nif nif;
    private Set<Telefono> telefonos = new HashSet<>();
    private Set<Coche> coches = new HashSet<>();

    public Persona() {
    }

    public Persona(String nombre, Nif nif) {
        this.nombre = nombre;
        this.nif = nif;
    }

    // Metodos de sincronizacion
    // uno por cada propiedad de tipo coleccion
    public void addTelefono(Telefono t){
        telefonos.add(t);
        t.setPersona(this);
    }

    public void addCoche(Coche c){
        coches.add(c);
        c.getPropietarios().add(this);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Nif getNif() {
        return nif;
    }

    public void setNif(Nif nif) {
        this.nif = nif;
    }

    public Set<Telefono> getTelefonos() {
        return telefonos;
    }

    public void setTelefonos(Set<Telefono> telefonos) {
        this.telefonos = telefonos;
    }

    public Set<Coche> getCoches() {
        return coches;
    }

    public void setCoches(Set<Coche> coches) {
        this.coches = coches;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Persona persona = (Persona) o;
        return Objects.equals(id, persona.id) && Objects.equals(nombre, persona.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre);
    }

    @Override
    public String toString() {
        return "Persona{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", nif=" + nif +
                ", telefonos=" + telefonos +
                ", coches=" + coches +
                '}';
    }
}
