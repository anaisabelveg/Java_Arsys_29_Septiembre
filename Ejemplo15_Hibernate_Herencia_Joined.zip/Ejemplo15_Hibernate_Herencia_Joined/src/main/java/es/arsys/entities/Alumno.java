package es.arsys.entities;

import java.io.Serializable;

public class Alumno extends Persona implements Serializable {

    private String curso;

    public Alumno(String nombre, String apellido, String curso) {
        super(nombre, apellido);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                super.toString() +
                "curso='" + curso + '\'' +
                "} ";
    }
}
