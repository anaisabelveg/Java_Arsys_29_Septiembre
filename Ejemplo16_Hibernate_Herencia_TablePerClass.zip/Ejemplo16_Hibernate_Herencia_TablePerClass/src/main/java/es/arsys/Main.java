package es.arsys;

import es.arsys.entities.Alumno;
import es.arsys.entities.Persona;
import es.arsys.entities.Profesor;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main {
    public static void main(String[] args) {

        StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        SessionFactory sf = new MetadataSources(registry).buildMetadata().buildSessionFactory();
        Session session = sf.openSession();  // En este momento se abre la conexion a la BDD
        Transaction tx = session.getTransaction();

        Persona persona = new Persona(1L, "Juan", "Lopez");
        Alumno alumno = new Alumno(2L, "Maria", "Perez", "Spring");
        Profesor profesor = new Profesor(3L, "Jose", "Sanchez", "Ingeniero Informatico");

        try {
            tx.begin();
            session.persist(persona);
            session.persist(alumno);
            session.persist(profesor);
            tx.commit();
            System.out.println("Entidades creadas");
        } catch (Exception ex){
            tx.rollback();
            ex.printStackTrace();
        } finally {
            session.close();
        }
    }
}