package es.arsys.entities;

import java.io.Serializable;

public class Profesor extends Persona implements Serializable {

    private String titulacion;

    public Profesor() {
    }

    public Profesor(Long id, String nombre, String apellido, String titulacion) {
        super(id, nombre, apellido);
        this.titulacion = titulacion;
    }

    public String getTitulacion() {
        return titulacion;
    }

    public void setTitulacion(String titulacion) {
        this.titulacion = titulacion;
    }

    @Override
    public String toString() {
        return "Profesor{" +
                super.toString() +
                "titulacion='" + titulacion + '\'' +
                "} ";
    }
}
