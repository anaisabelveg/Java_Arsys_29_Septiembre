package es.arsys;

import es.arsys.business.Contabilidad;

public class Main {
    public static void main(String[] args) {

        Contabilidad libro1 = Contabilidad.getInstance();
        Contabilidad libro2 = Contabilidad.getInstance();

        // Comprobamos si es la misma instancia
        System.out.println("Es la misma instancia? " + (libro1 == libro2));

        libro1.movimiento("Pago de nominas");
        libro2.movimiento("Compra de material de oficina");
    }
}