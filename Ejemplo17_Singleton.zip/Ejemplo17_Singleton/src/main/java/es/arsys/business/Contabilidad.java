package es.arsys.business;

public class Contabilidad {

    // Almacenamos la unica instancia de la clase
    private static Contabilidad instance = new Contabilidad();

    // quitar acceso al constructor y evitamos el crear nuevas instancias
    private Contabilidad() {
    }

    // Metodo estatico alternativo para obtener la instancia
    // En Spring, Factoria estatica
    public static Contabilidad getInstance(){
        return instance;
    }

    public void movimiento(String datos){
        System.out.println(datos + " anotado en el libro de contabilidad");
    }
}
