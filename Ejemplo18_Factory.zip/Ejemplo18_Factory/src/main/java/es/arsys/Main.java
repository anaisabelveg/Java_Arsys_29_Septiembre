package es.arsys;

import es.arsys.business.Servicio;
import es.arsys.business.ServicioFactory;

public class Main {
    public static void main(String[] args) {

        Servicio servicio = ServicioFactory.create("jsonhtgvhgvkhgvkh");
        System.out.println(servicio.obtenerDatos(3));

    }
}