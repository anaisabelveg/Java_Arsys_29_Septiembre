package es.arsys.business;

public interface Servicio {

    public String obtenerDatos(int codigo);
}
