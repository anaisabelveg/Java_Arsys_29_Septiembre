package es.arsys.business;

public class ServicioFactory {

    public static Servicio create(String formato){
        if (formato.toLowerCase().equals("xml")){
            return  new ServicioXML();
        } else {
            return  new ServicioJSON();
        }
    }
}
