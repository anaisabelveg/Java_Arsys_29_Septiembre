package es.arsys.business;

public class ServicioJSON implements Servicio {

    @Override
    public String obtenerDatos(int codigo) {
        // Simulamos una consulta a la BBDD
        // donde buscamos una registro con
        // ese codigo y la informacion obtenida
        // la devolvemos en formato JSON
        return "{" +
                    "id:" + codigo +
                    ", descripcion: Producto " + codigo +
                    ", precio:" + codigo * 100 +
                "}";
    }
}
