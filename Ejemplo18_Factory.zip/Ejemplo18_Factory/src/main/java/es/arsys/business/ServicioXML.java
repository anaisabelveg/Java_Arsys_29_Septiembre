package es.arsys.business;

public class ServicioXML implements Servicio {

    @Override
    public String obtenerDatos(int codigo) {
        // Simulamos una consulta a la BBDD
        // donde buscamos una registro con
        // ese codigo y la informacion obtenida
        // la devolvemos en formato XML
        return "<?xml version='1.0'>" +
               "<producto>" +
                    "<id>" + codigo + "</id>" +
                    "<descripcion> Producto " + codigo + "</descripcion>" +
                    "<precio>" + codigo * 100 + "</precio>" +
                "</producto>";
    }
}
