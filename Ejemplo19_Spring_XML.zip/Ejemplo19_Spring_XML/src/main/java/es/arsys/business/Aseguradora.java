package es.arsys.business;

import es.arsys.models.Coche;

public class Aseguradora {

    private String nombre;
    private ITaller taller;

    public Aseguradora() {
    }

    public Aseguradora(String nombre, ITaller taller) {
        this.nombre = nombre;
        this.taller = taller;
    }

    public void arreglarCoche(Coche coche){
        taller.reparar(coche);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ITaller getTaller() {
        return taller;
    }

    public void setTaller(ITaller taller) {
        this.taller = taller;
    }

}
