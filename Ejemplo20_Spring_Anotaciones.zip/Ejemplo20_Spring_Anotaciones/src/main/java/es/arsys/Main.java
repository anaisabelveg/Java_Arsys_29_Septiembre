package es.arsys;

import es.arsys.business.Aseguradora;
import es.arsys.models.Coche;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        // Levantar el contexto de Spring leyendo el archivo.xml que es donde forzamos la creacion de los beans
        ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Recuperar el bean coche
        Coche coche = (Coche) contenedor.getBean("coche");

        // Recuperar el bean aseguradora
        Aseguradora aseguradora = contenedor.getBean("aseguradora", Aseguradora.class);

        aseguradora.arreglarCoche(coche);
    }
}