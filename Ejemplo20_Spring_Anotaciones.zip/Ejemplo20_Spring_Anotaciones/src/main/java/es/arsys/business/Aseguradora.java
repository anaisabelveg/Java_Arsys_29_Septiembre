package es.arsys.business;

import es.arsys.models.Coche;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class Aseguradora {

    @Value("Mapfre")
    private String nombre;

    /*
    * Para inyectar un bean tenemos varias formas de hacerlo:
    * @Autowired no permite elegir el bean a inyectar
    * @Resource puedo elegir el nombre del bean a inyectar
    * */
    //@Resource(name = "tallerPintura")
    @Autowired   // solo con esta anotacion da error al tener 2 beans de tipo taller
    //@Qualifier(value = "tallerPintura")  // solucion 1 poner el nombre del bean a inyectar
    // solucion 2: dar prioridad al bean que quiero inyectar @Primary
    private ITaller taller;

    public Aseguradora() {
    }

    public Aseguradora(String nombre, ITaller taller) {
        this.nombre = nombre;
        this.taller = taller;
    }

    public void arreglarCoche(Coche coche){
        taller.reparar(coche);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ITaller getTaller() {
        return taller;
    }

    public void setTaller(ITaller taller) {
        this.taller = taller;
    }

}
