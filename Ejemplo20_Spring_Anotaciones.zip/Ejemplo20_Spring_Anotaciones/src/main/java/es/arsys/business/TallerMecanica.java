package es.arsys.business;

import es.arsys.models.Coche;
import org.springframework.stereotype.Service;

/* Anotaciones para anotar la clase y crear un bean de Spring:
* @Repository; para repositorios de datos xxxxDAO
* @Controller; para los controladores que en Spring sustituyen a los Servlets
* @Service; para Business, logica de negocio, servicios, ...etc
* @Component; estandard, si tu clase no se corresponde con ninguna de las anteriores
* */

// Si no le ponemos un nombre al bean cogera el nombre de la clase con la primera letra en minuscula
@Service
public class TallerMecanica implements ITaller{

    @Override
    public void reparar(Coche coche) {
        System.out.println("En el taller de mecanica se repara el coche " + coche);
    }
}
