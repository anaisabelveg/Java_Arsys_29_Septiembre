package es.arsys.business;

import es.arsys.models.Coche;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service("tallerPintura")  // id del bean
@Primary   // le damos prioridad en la DI
public class TallerPintura implements ITaller{

    @Override
    public void reparar(Coche coche) {
        System.out.println("En el taller de pintura pintamos el coche " + coche);
    }
}
