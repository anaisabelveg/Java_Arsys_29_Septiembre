package es.arsys.models;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Coche {

    // Inyeccion de dependencias (DI) por propiedad
    @Value("1234-MDB")  // Inyectamos valores: tipos primitivos y String
    private String matricula;

    @Value("A5")
    private String modelo;

    public Coche() {
    }

    /*
    * Si hacemos la inyeccion de dependencias por constructor:
    *       Hay que eliminar el constructor por defecto
    *
    public Coche(@Value("1234-MDB") String matricula, @Value("A5") String modelo) {
        this.matricula = matricula;
        this.modelo = modelo;
    }
     */

    public Coche(String matricula, String modelo) {
        this.matricula = matricula;
        this.modelo = modelo;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    @Override
    public String toString() {
        return "Coche{" +
                "matricula='" + matricula + '\'' +
                ", modelo='" + modelo + '\'' +
                '}';
    }
}
