package es.arsys;

import es.arsys.business.Aseguradora;
import es.arsys.config.JavaConfig;
import es.arsys.models.Coche;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        // Levantar el contexto de Spring
        // Leer la clase de configuracion y por cada bean declarado
        // lo crea y lo mete en el contenedor
        ApplicationContext contenedor = new AnnotationConfigApplicationContext(JavaConfig.class);

        // Recuperar el bean coche
        Coche coche = (Coche) contenedor.getBean("coche");

        // Recuperar el bean aseguradora
        Aseguradora aseguradora = contenedor.getBean("aseguradora", Aseguradora.class);

        aseguradora.arreglarCoche(coche);
    }
}