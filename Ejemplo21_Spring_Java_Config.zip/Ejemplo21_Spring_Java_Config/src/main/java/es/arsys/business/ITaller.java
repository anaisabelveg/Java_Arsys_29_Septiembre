package es.arsys.business;

import es.arsys.models.Coche;

public interface ITaller {

    void reparar(Coche coche);
}
