package es.arsys.business;

import es.arsys.models.Coche;

public class TallerMecanica implements ITaller{

    @Override
    public void reparar(Coche coche) {
        System.out.println("En el taller de mecanica se repara el coche " + coche);
    }
}
