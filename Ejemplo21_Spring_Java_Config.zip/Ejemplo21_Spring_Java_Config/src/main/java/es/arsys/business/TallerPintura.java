package es.arsys.business;

import es.arsys.models.Coche;

public class TallerPintura implements ITaller{

    @Override
    public void reparar(Coche coche) {
        System.out.println("En el taller de pintura pintamos el coche " + coche);
    }
}
