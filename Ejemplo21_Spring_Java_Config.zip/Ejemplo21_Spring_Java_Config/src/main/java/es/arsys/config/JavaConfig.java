package es.arsys.config;

import es.arsys.business.Aseguradora;
import es.arsys.business.TallerMecanica;
import es.arsys.business.TallerPintura;
import es.arsys.models.Coche;
import org.springframework.context.annotation.*;

@Configuration   // Marca la clase como una clase de configuracion
// @ImportResource("applicationContext.xml")
// Si fuese en xml  <import ---->
public class JavaConfig {

    // El nombre del metodo es el identificador del bean
    @Bean  // Hace que el objeto Java se convierta en un bean de Spring
    @Scope(value = "prototype")
    @Lazy(value = true)
    public TallerMecanica tallerMecanica(){
        return new TallerMecanica();
    }

    @Bean
    public TallerPintura tallerPintura(){
        return new TallerPintura();
    }

    @Bean
    public Coche coche(){
        // DI a través del constructor
        return new Coche("1234-MDB", "A5");
    }

    @Bean
    public Aseguradora aseguradora(){
        // DI a través de propiedades
        Aseguradora aseguradora = new Aseguradora();
        aseguradora.setNombre("Mapfre");
        aseguradora.setTaller(tallerPintura());
        return aseguradora;
    }
}
