package es.arsys.rest;

import es.arsys.models.Producto;
import es.arsys.persistence.ProductosDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductosREST {

    @Autowired
    private ProductosDAO dao;

    // http://localhost:9001/todos
    @GetMapping("/todos")
    public List<Producto> consultarTodos(){
        return dao.findAll();
    }

    // http://localhost:9001/buscar/3
    @GetMapping("/buscar/{codigo}")
    public Producto buscarProducto(@PathVariable(name = "codigo") Long id){
        return dao.findById(id).orElse(new Producto());
    }

    // http://localhost:9001/crear/desc/Prueba/precio/234
    @PostMapping("/crear/desc/{descripcion}/precio/{precio}")
    public Producto crearProducto(@PathVariable String descripcion, @PathVariable double precio){
        return dao.save(new Producto(descripcion, precio));
    }

    // http://localhost:9001/eliminar/7
    @DeleteMapping("/eliminar/{id}")
    public void eliminarProducto(@PathVariable Long id){
        dao.deleteById(id);
    }

    // http://localhost:9001/modificar/3/desc/Raton inalambrico/precio/28
    @PutMapping("/modificar/{id}/desc/{descripcion}/precio/{precio}")
    public Producto modificarProducto(@PathVariable Long id, @PathVariable String descripcion, @PathVariable double precio){
        Producto producto = buscarProducto(id);
        producto.setDescripcion(descripcion);
        producto.setPrecio(precio);
        return dao.save(producto);
    }
}
