package es.arsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo22SpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
