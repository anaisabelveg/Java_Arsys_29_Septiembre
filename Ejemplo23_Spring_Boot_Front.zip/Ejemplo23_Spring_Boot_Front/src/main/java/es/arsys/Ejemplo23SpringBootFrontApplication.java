package es.arsys;

import es.arsys.business.IGestionBS;
import es.arsys.models.Producto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo23SpringBootFrontApplication implements CommandLineRunner {

	@Autowired
	private IGestionBS bs;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo23SpringBootFrontApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		/*
		bs.nuevoProducto(new Producto("xxxxxxx", 287.23));

		Producto prod = new Producto();
		prod.setID(7L);
		prod.setDescripcion("Nuevo");
		prod.setPrecio(9999);
		bs.actualizarProducto(prod);

		bs.eliminarProducto(7L);

		bs.obtenerTodos().forEach(System.out::println);
		System.out.println("--------------");

		System.out.println(bs.buscarProducto(2L));
		*/

	}
}
