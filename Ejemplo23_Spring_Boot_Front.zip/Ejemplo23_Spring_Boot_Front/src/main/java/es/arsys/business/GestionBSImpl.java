package es.arsys.business;

import com.fasterxml.jackson.databind.ObjectMapper;
import es.arsys.models.Producto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class GestionBSImpl implements IGestionBS{

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public List<Producto> obtenerTodos() {
        String url = "http://localhost:9001/todos";
        //return restTemplate.getForObject(url, java.util.List.class);   DA ERROR
        Object[] array = restTemplate.getForEntity(url, Object[].class).getBody();
        ObjectMapper mapper = new ObjectMapper();
        return Arrays.stream(array)
                .map(object -> mapper.convertValue(object, Producto.class))
                .collect(Collectors.toList());
    }

    @Override
    public Producto buscarProducto(Long id) {
        String url = "http://localhost:9001/buscar/{codigo}";
        return restTemplate.getForObject(url, Producto.class, id);
    }

    @Override
    public Producto nuevoProducto(Producto nuevo) {
        String url = "http://localhost:9001/crear/desc/{descripcion}/precio/{precio}";
        return restTemplate.postForObject(url, null, Producto.class, nuevo.getDescripcion(), nuevo.getPrecio());
    }

    @Override
    public void eliminarProducto(Long id) {
        String url = "http://localhost:9001/eliminar/{id}";
        restTemplate.delete(url, id);
    }

    @Override
    public Producto actualizarProducto(Producto actualizado) {
        String url = "http://localhost:9001/modificar/{id}/desc/{descripcion}/precio/{precio}";
        restTemplate.put(url,null,actualizado.getID(), actualizado.getDescripcion(), actualizado.getPrecio());
        return buscarProducto(actualizado.getID());
    }
}
