package es.arsys.business;

import es.arsys.models.Producto;

import java.util.List;

public interface IGestionBS {

    List<Producto> obtenerTodos();

    Producto buscarProducto(Long id);

    Producto nuevoProducto(Producto nuevo);

    void eliminarProducto(Long id);

    Producto actualizarProducto(Producto actualizado);
}
