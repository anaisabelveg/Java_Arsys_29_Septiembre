package es.arsys.controllers;

import es.arsys.business.IGestionBS;
import es.arsys.models.Producto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/buscar")
public class BuscarController {

    @Autowired
    private IGestionBS bs;

    @RequestMapping(method = RequestMethod.GET)
    public String mostrarFormulario(Model model){
        model.addAttribute("prod", new Producto());
        return "formBuscar";
    }

    @RequestMapping(method = RequestMethod.POST)
    public String procesarFormulario(Producto producto, Model model){
        Producto encontrado = bs.buscarProducto(producto.getID());
        if (encontrado.getDescripcion() == null){
            model.addAttribute("msg", "Ese producto no existe en nuestro calogo");
            return "mostrarMensaje";
        } else {
            model.addAttribute("encontrado", encontrado);
            return "mostrarProducto";
        }
    }
}
