package es.arsys.controllers;

import es.arsys.models.Carrito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@Scope("session")
@RequestMapping("/")
public class CarritoController {

    @Autowired
    private Carrito carrito;

    @RequestMapping(value = "comprar", method = RequestMethod.POST)
    public String comprarProducto(Long id, Model model){
        carrito.addProducto(id);
        model.addAttribute("carrito", carrito);
        return "mostrarCarrito";
    }

    @RequestMapping(value = "sacar", method = RequestMethod.GET)
    public String eliminarProducto(Long id, Model model){
        carrito.sacarProducto(id);
        model.addAttribute("carrito", carrito);
        return "mostrarCarrito";
    }
}
