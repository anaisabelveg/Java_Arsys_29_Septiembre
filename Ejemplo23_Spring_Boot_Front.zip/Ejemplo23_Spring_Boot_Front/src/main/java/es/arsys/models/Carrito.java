package es.arsys.models;

import es.arsys.business.IGestionBS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Scope("session")
public class Carrito {

    @Autowired
    private IGestionBS bs;

    private List<Producto> contenido = new ArrayList<>();
    private double importe;

    public void addProducto(Long id){
        Producto producto = bs.buscarProducto(id);
        contenido.add(producto);
        importe += producto.getPrecio();
    }

    public void sacarProducto(Long id){
        Producto encontrado = contenido.stream()
                .filter(prod -> prod.getID() == id)
                .findFirst()
                .get();
        contenido.remove(encontrado);
        importe -= encontrado.getPrecio();
    }

    public List<Producto> getContenido() {
        return contenido;
    }

    public double getImporte() {
        return importe;
    }
}
