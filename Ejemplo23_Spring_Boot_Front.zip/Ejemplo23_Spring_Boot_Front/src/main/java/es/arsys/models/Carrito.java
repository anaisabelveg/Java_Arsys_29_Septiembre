package es.arsys.models;

import java.util.ArrayList;
import java.util.List;

public class Carrito {

    private List<Producto> contenido = new ArrayList<>();
    private double importe;

    public void addProducto(Long id){

    }

    public void sacarProducto(Long id){

    }

    public List<Producto> getContenido() {
        return contenido;
    }

    public double getImporte() {
        return importe;
    }
}
