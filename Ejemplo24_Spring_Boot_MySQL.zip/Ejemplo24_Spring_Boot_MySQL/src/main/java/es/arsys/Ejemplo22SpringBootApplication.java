package es.arsys;

import es.arsys.models.Producto;
import es.arsys.persistence.ProductosDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo22SpringBootApplication implements CommandLineRunner {

	@Autowired
	private ProductosDAO dao;

	public static void main(String[] args) {
		// Este metodo se dedica exclusivamente a levantar la aplicacion
		SpringApplication.run(Ejemplo22SpringBootApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Alternativa al metodo main que se ejecuta a continuacion de este

		// Insertar nuevo producto
		dao.save(new Producto("Prueba", 234));

		// Mostrar todos los productos
		dao.findAll().forEach(System.out::println);
		System.out.println("------------------------");

		// Buscar un producto por id
		System.out.println(dao.findById(3L).get());
		System.out.println("------------------------");

		// Buscar un producto por descripcion
		dao.findByDescripcion("Scanner").forEach(System.out::println);
		System.out.println("------------------------");

		// Buscar productos entre 100 y 200 euros
		dao.findByPrecioBetween(100,200).forEach(System.out::println);
		System.out.println("------------------------");

		// Buscar productos entre 20 y 200 euros ordenados por descripcion
		dao.findByPrecioBetweenOrderByDescripcion(20,200).forEach(System.out::println);
		System.out.println("------------------------");

		// Buscar productos entre 20 y 200 euros ordenados por descripcion descendente
		dao.findByPrecioBetweenOrderByDescripcionDesc(20,200).forEach(System.out::println);
		System.out.println("------------------------");
	}
}
