package es.arsys.persistence;

import es.arsys.models.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

// En Spring Boot todas las clases que heredan de xxxRepository se genera el bean automaticamente
public interface ProductosDAO extends JpaRepository<Producto, Long> {

    // https://docs.spring.io/spring-data/jpa/reference/repositories/query-keywords-reference.html
    // Con keywords podemos crear metodos personalizados

    public List<Producto> findByDescripcion(String descripcion);
    public List<Producto> findByPrecioBetween(double min, double max);
    public List<Producto> findByPrecioBetweenOrderByDescripcion(double min, double max);
    public List<Producto> findByPrecioBetweenOrderByDescripcionDesc(double min, double max);
}
