package es.arsys.models;

import es.arsys.utils.PrecioNegativoException;

import java.io.Serializable;
import java.util.Objects;

public class Producto implements Serializable {

    private Long ID;
    private String descripcion;
    private double precio;

    public Producto() {
    }

    public Producto(Long ID, String descripcion, double precio) {
        this.ID = ID;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio < 0)
            throw new PrecioNegativoException("El precio no puede ser negativo");
        this.precio = precio;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Producto producto = (Producto) o;
        return Double.compare(producto.precio, precio) == 0 && Objects.equals(ID, producto.ID) && Objects.equals(descripcion, producto.descripcion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID, descripcion, precio);
    }

    @Override
    public String toString() {
        return "Producto{" +
                "ID=" + ID +
                ", descripcion='" + descripcion + '\'' +
                ", precio=" + precio +
                '}';
    }
}
