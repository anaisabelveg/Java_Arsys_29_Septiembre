package es.arsys.models;

import es.arsys.utils.PrecioNegativoException;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class ProductoTest {

    Producto producto;
    static Proveedor proveedor;


    @BeforeAll
    // Debe ser estatico
    public static void inicioClasePrueba(){
        // Iniciamos un log para almacenar el resultado de las pruebas
        System.out.println("Empezamos a probar la clase ProductoTest");

        proveedor = new Proveedor();
        proveedor.setNombre("HP");
    }

    @AfterAll
    // Debe ser estatico
    public static void finClasePrueba(){
        // Cerrar el log
        System.out.println("Terminamos de probar la clase ProductoTest");
    }

    @BeforeEach
    void inicioMetodoTest(){  // los metodos de toda la clase pueden ser default, no tienen porque ser publicos
        // Crear el producto
        producto = new Producto(1L,"Impresora",129.95);
        System.out.println("Producto creado para realizar la prueba");
    }

    @AfterEach
    void finMetodoTest(){
        System.out.println("Prueba finalizada");
    }

    @Nested
    @DisplayName("Probando los test de la clase Producto")
    @Disabled
    class ProductoPruebas{
        @Test
        @DisplayName("Probando la descripcion de la clase Producto")
        public void testDescripcion(){
            //Producto producto = new Producto(1L,"Impresora",129.95);
            String descripcionReal = producto.getDescripcion();
            String descripcionEsperada = "Impresora";
            Assertions.assertEquals(descripcionEsperada, descripcionReal);
        }

        @Test
        public void testPrecio(){
            //Producto producto = new Producto(1L,"Impresora",129.95);
            // Comprobamos que el precio no es negativo, ni igual a 0
            //Assertions.assertTrue(producto.getPrecio() > 0);
            Assertions.assertFalse(producto.getPrecio() <= 0);
        }

        @Test
        public void testPrecioException(){
            //Producto producto = new Producto(1L,"Impresora",129.95);

            // Comprobar que lanza la excepcion cuando asignamos un precio negativo
        /*
        Assertions.assertThrows(PrecioNegativoException.class, () -> {
            producto.setPrecio(-25);
        });  */

            // Comprobar el mensaje de la excepcion
            Exception exception = Assertions.assertThrows(PrecioNegativoException.class, () -> {
                producto.setPrecio(-25);
            });
            String msgReal = exception.getMessage();
            //String msgEsperado = "Precio negativo";
            String msgEsperado = "El precio no puede ser negativo";
            Assertions.assertEquals(msgReal, msgEsperado);
        }

        @Test
        @Disabled
        public void testIgualdadProductos(){
            //Producto producto = new Producto(1L,"Impresora",129.95);
            Producto producto2 = new Producto(1L,"Impre",129.95);
            Assertions.assertEquals(producto,producto2);
        }
    }

    @Nested
    @DisplayName("Probando los test de la clase Proveedor")
    @Disabled
    class ProveedorPruebas{

        @Test
        void testRelaccionProductoProveedor(){
            Producto producto2 = new Producto(2L,"Monitor",156.50);

            Proveedor proveedor = new Proveedor();
            proveedor.setNombre("HP");

            proveedor.getProductos().add(producto);
            proveedor.getProductos().add(producto2);

            // Comprobar que la lista de productos no es nula
            // Assertions.assertNotNull(proveedor.getProductos());

            // Comprobamos el tamaño de la lista
            //Assertions.assertEquals(3, proveedor.getProductos().size(), "El proveedor deberia tener 2 productos");

            // Comprobar que el proveedor tiene un producto "Impresora"
            /*
            Assertions.assertEquals("Scanner", proveedor.getProductos().stream()
                    .filter(prod -> prod.getDescripcion().equals("Scanner"))
                    .findFirst()
                    .get()
                    .getDescripcion());  */

            // Forzar para que se ejecuten las 3 aserciones, aunque falle alguna continua con el resto
            Assertions.assertAll(
                    () -> Assertions.assertNotNull(proveedor.getProductos()),
                    () -> Assertions.assertEquals(3, proveedor.getProductos().size(), "El proveedor deberia tener 2 productos"),
                    () -> Assertions.assertEquals("Scanner", proveedor.getProductos().stream()
                            .filter(prod -> prod.getDescripcion().equals("Scanner"))
                            .findFirst()
                            .get()
                            .getDescripcion())
            );
        }
    }


    @Nested
    @DisplayName("Habilitar o deshabilitar segun SO, JRE")
    @Disabled
    class SO_JRE{

        @Test
        @EnabledOnOs(OS.WINDOWS)
        void testSOWindows(){
            System.out.println("Se ejecuta si el SO es Windows");
        }

        @Test
        @EnabledOnOs({OS.MAC, OS.LINUX})
        void testSOMacLinux(){
            System.out.println("Se ejecuta si el SO es Mac o Linux");
        }

        @Test
        @DisabledOnOs(OS.WINDOWS)
        void testSONoWindows(){
            System.out.println("Se deshabilita si el SO es Windows");
        }

        @Test
        @EnabledOnJre(JRE.JAVA_8)
        // No es Java 8 o superior, sino la version ha de ser java 8 exactamente
        void testSoloJRE8(){
            System.out.println("Probando test en Java 8");
        }

        @Test
        @EnabledOnJre(JRE.JAVA_21)
        void testSoloJRE21(){
            System.out.println("Probando test en Java 21");
        }

        @Test
        @DisabledOnJre(JRE.JAVA_8)
        void testNoJava8(){
            System.out.println("Deshabilitado el test en Java 8");
        }
    }

    @Nested
    @DisplayName("Pruebas de System Properties")
    @Disabled
    class SystemProperties{

        @Test
        void verSystemProperties(){
            Properties properties = System.getProperties();
            //properties.forEach((k,v) -> System.out.println(k + ": " + v));
        }

        // java.version: 1.8.0_111
        @Test
        @EnabledIfSystemProperty(named = "java.version", matches = "1.8.0_111")
        void testJavaVersion(){
            System.out.println("Tu version de java es 1.8.0_111");
        }

        // Tambien funciona con expresiones regulares
        @Test
        @EnabledIfSystemProperty(named = "java.version", matches = "1.8.*")
        void testJavaVersion2(){
            System.out.println("Tu version de java es 1.8.*");
        }

        @Test
        @DisabledIfSystemProperty(named = "java.version", matches = "1.8.*")
        void testNoJavaVersion2(){
            System.out.println("Tu version de java no es 1.8.*");
        }
    }

    // Tambien teneis las variables de Entorno: @EnabledIfEnvironmentVariable() @DisabledIfEnvironmentVariable()

    @RepeatedTest(value = 3, name = "Repeticion nº {currentRepetition} del total de {totalRepetitions}")
    void testRepetido(RepetitionInfo infoRep){
        System.out.println("Estamos en la repeticion numero: " + infoRep.getCurrentRepetition());
        double numero = Math.random();
        System.out.println(numero);
        Assertions.assertNotNull(numero);
        Assertions.assertTrue(numero > 0);
    }

    // Test parametrizados: se trata de pasar varios datos como parametros
    // y asi poder realizar la prueba con cada uno de ellos
    @ParameterizedTest(name = "parametro {index} con valor {0}")
    @ValueSource(doubles = {57, 0, -12})   // array con los parametros
    void testPrecios(double precio){
        producto.setPrecio(precio);
        Assertions.assertTrue(producto.getPrecio() > 0);
    }

    @ParameterizedTest(name = "parametro {index} con valor {0}")
    @CsvSource({"57", "0", "-12"})   // csv con los parametros
    void testPreciosCsv(double precio){
        producto.setPrecio(precio);
        Assertions.assertTrue(producto.getPrecio() > 0);
    }

    @ParameterizedTest(name = "parametro {index} con valor {0}")
    @CsvFileSource(resources = "/datos.csv") // archivo csv con los parametros
    void testPreciosCsvFileSource(double precio){
        producto.setPrecio(precio);
        Assertions.assertTrue(producto.getPrecio() > 0);
    }

    @ParameterizedTest(name = "parametro {index} con valor {0}")
    @MethodSource("queryPrecios") // metodo que retorna los parametros
    void testPreciosMethodSource(double precio){
        producto.setPrecio(precio);
        Assertions.assertTrue(producto.getPrecio() > 0);
    }

    static List<Double> queryPrecios(){
        // Simulamos que lanzamos un query a la BBDD para traer todos los precios
        return Arrays.asList(57.0, 0.0 , -12.0);
    }

    // Ejercicio
    //  1.- Crear un productos.csv con 4 productos id,descripcion,precio
    //  2.- Rehacer la prueba de testear la relaccion entre productos y proveedor
    //        con los test parametrizados
    @ParameterizedTest
    @CsvFileSource(resources = "/productos.csv")
    void testRelaccionProductoProveedorCsv(long id, String descripcion, double precio){

        Producto producto = new Producto(id, descripcion, precio);
        proveedor.getProductos().add(producto);

        // Comprobar que la lista de productos no es nula
        //Assertions.assertNotNull(proveedor.getProductos());

        // Comprobamos el tamaño de la lista
        //Assertions.assertEquals(4, proveedor.getProductos().size(), "El proveedor deberia tener 4 productos");

        // Comprobar que el proveedor tiene un producto "Impresora"

            Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
                    .filter(prod -> prod.getDescripcion().equals("Impresora"))
                    .findFirst()
                    .get()
                    .getDescripcion());

        // Forzar para que se ejecuten las 3 aserciones, aunque falle alguna continua con el resto
        /*
        Assertions.assertAll(
                () -> Assertions.assertNotNull(proveedor.getProductos()),
                () -> Assertions.assertEquals(3, proveedor.getProductos().size(), "El proveedor deberia tener 2 productos"),
                () -> Assertions.assertEquals("Scanner", proveedor.getProductos().stream()
                        .filter(prod -> prod.getDescripcion().equals("Scanner"))
                        .findFirst()
                        .get()
                        .getDescripcion())
        );*/
    }
}








