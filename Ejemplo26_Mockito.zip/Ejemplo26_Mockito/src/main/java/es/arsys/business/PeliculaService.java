package es.arsys.business;

import es.arsys.models.Pelicula;
import es.arsys.persistence.PeliculasDAO;

import java.util.Optional;

public class PeliculaService {

    private PeliculasDAO dao;

    public PeliculaService(PeliculasDAO dao) {
        this.dao = dao;
    }

    public Pelicula findPeliculaByNombre(String nombre){
        Optional<Pelicula> opPelicula = dao.findAll().stream()
                .filter(peli -> peli.getNombre().contains(nombre))
                .findFirst();

        Pelicula pelicula = null;
        if (opPelicula.isPresent()){
            pelicula = opPelicula.get();
        }
        return pelicula;
    }

    public Pelicula findPeliculaByNombreConActores(String nombre){
        //buscar la pelicula
        // buscar los actores en ActoresDAO
        // En la pelicula asignamos los actores en la lista
        return  null;
    }
}
