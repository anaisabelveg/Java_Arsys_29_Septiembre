package es.arsys.models;

import java.util.Arrays;
import java.util.List;

public class Datos {

    public static List<Pelicula> PELICULAS = Arrays.asList(
            new Pelicula(1L, "El 47"),
            new Pelicula(2L, "La Infiltrada"),
            new Pelicula(3L, "La habitacion de al lado"));
}
