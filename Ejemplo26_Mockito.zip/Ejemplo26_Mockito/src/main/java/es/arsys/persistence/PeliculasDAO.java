package es.arsys.persistence;

import es.arsys.models.Pelicula;

import java.util.Arrays;
import java.util.List;

public class PeliculasDAO {

    public List<Pelicula> findAll(){
        System.out.println("Metodo findAll de PeliculasDAO");
        return Arrays.asList(
                new Pelicula(1L, "El 47"),
                new Pelicula(2L, "La Infiltrada"),
                new Pelicula(3L, "La habitacion de al lado")
        );
    }
}
