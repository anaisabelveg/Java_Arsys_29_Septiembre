package es.arsys.business;

import es.arsys.models.Datos;
import es.arsys.models.Pelicula;
import es.arsys.persistence.PeliculasDAO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class PeliculaServiceTest {

    @Mock   // PeliculasDAO dao = Mockito.mock(PeliculasDAO.class);
    PeliculasDAO dao;

    @InjectMocks   // PeliculaService service = new PeliculaService(dao);
    PeliculaService service;

    @BeforeEach
    void inicioPrueba(){
        //MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindPeliculaByNombre(){
        // Creo un Mock (objeto ficticio)
        // No se puede crear un mock de cualquier metodo, solo metodos public o default
        // PeliculasDAO dao = Mockito.mock(PeliculasDAO.class);
        // PeliculaService service = new PeliculaService(dao);

        // Al usar anotaciones necesitamos activarlas:
        //      1ª forma: anotacion @ExtendWith
        //      2ª forma: MockitoAnnotations.openMocks(this)

        // Cuando pedimos buscar todas las peliculas retornar unos datos ficticios
        Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);

        Pelicula pelicula = service.findPeliculaByNombre("habitacion");
        Assertions.assertNotNull(pelicula);
        Assertions.assertEquals(3L, pelicula.getId());
        Assertions.assertEquals("La habitacion de al lado", pelicula.getNombre());
    }

    @Test
    void testFindPeliculaByNombreConActores() {
    
    }
}
